# Excaliplan — Free-form Trip Planner

A Next.js web app that combines the freedom of an Excalidraw canvas with practical trip tools:
- Lists: things to pack, to buy, todos — with quantities, per-item currency, and auto totals in your base currency.
- Budget: set total & per-category limits, log expenses in any currency, and see remaining instantly.
- Price Watch (optional): monitor flight prices via Kiwi Tequila or Amadeus and deep-link to booking.
- Currency: live rates via exchangerate.host.
- Deployable to Vercel with scheduled Cron to refresh price watches.

## 1) Quick start

```bash
npm i
npm run dev
# open http://localhost:3000
```

## 2) Environment (optional but recommended)

Create `.env.local` with any of the following:

```ini
# For Kiwi Tequila flight search
TEQUILA_API_KEY=your_key_here

# For Amadeus Self-Service APIs (test environment by default)
AMADEUS_CLIENT_ID=...
AMADEUS_CLIENT_SECRET=...

# Vercel KV (optional for persistent watchlist)
VERCEL_KV_REST_API_URL=...
VERCEL_KV_REST_API_TOKEN=...

# For cron self-calls during reprice (set to your deployment origin)
SELF_BASE_URL=https://your-app.vercel.app
```

> Booking: This template **redirects** to providers (deep links) for booking. Taking payments requires additional contracts/compliance.

## 3) Deploy to Vercel + Cron

- Push to GitHub and import repo into Vercel.
- Add your env vars in Vercel Project → Settings → Environment Variables.
- Keep `vercel.json` to run `/api/cron/reprice` every 6 hours.
- (Optional) Add Vercel KV (Upstash Redis) and set the two KV env vars. Without KV, the watchlist uses in-memory storage (works locally only).

## 4) Notes on Google Trips / Google Travel

Google Trips (the mobile app) was discontinued on **Aug 5, 2019**; the web experience lives on as **Google Travel**. There is **no official public API** for Google Trips/Travel. Instead, we recommend integrating:
- Google Maps Routes API for distances and ETAs
- Google Calendar export/import (ICS) for your itinerary
- Gmail/Amadeus/Skyscanner/Kiwi for price monitoring & booking deep-links

See the inline comments and the /watch page for the price watch UX.

## 5) Where things live

- `app/page.js` — main UI (tabs: Plan / Lists / Budget). Excalidraw is embedded here.
- `app/ui/Lists.js` — list manager with per-item currency.
- `app/ui/Budget.js` — budget & expense tracker.
- `app/api/rates/route.js` — currency rates proxy (exchangerate.host).
- `app/watch/page.js` — simple UI for creating flight price watches.
- `app/api/price-watch/route.js` — watchlist storage (KV or memory).
- `app/api/providers/flights.js` — Kiwi & Amadeus adapters.
- `app/api/cron/reprice/route.js` — cron endpoint to refresh watches.

## 6) Roadmap ideas

- PWA installable icon + offline cache for Excalidraw data
- Google Calendar sync (OAuth) or ICS export of your itinerary
- Hotel & car price watches (Skyscanner or Amadeus)
- Shared canvases (live collaboration) via WebRTC or Supabase
- Push/email notifications on price drops
- Per-trip workspaces (multiple canvases + scoped lists/budgets)
