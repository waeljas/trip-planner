export const revalidate = 3600; // 1 hour
export async function GET(req){
  const { searchParams } = new URL(req.url);
  const base = searchParams.get('base') || 'USD';
  const url = `https://api.exchangerate.host/latest?base=${encodeURIComponent(base)}`;
  const res = await fetch(url, { next: { revalidate: 3600 } });
  const data = await res.json();
  return new Response(JSON.stringify({ base, rates: data.rates||{} }), { headers: { 'content-type':'application/json' } });
}
