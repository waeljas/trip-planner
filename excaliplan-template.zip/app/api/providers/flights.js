export async function searchFlightKiwi({ from, to, date, adults=1, currency='USD' }){
  const url = new URL('https://api.tequila.kiwi.com/v2/search');
  url.searchParams.set('fly_from', from);
  url.searchParams.set('fly_to', to);
  url.searchParams.set('date_from', date);
  url.searchParams.set('date_to', date);
  url.searchParams.set('adults', String(adults));
  url.searchParams.set('curr', currency);
  url.searchParams.set('limit', '1');
  const res = await fetch(url.toString(), { headers: { 'apikey': process.env.TEQUILA_API_KEY } });
  if (!res.ok) throw new Error('Kiwi API error');
  const data = await res.json();
  const best = data?.data?.[0] ? ({
    price: data.data[0].price,
    deepLink: data.data[0].deep_link,
    route: data.data[0].route?.map(r => ({ from: r.cityFrom, to: r.cityTo, flightNo: r.airline + r.flight_no }))
  }) : null;
  return { provider: 'kiwi', best };
}

async function amadeusToken(){
  const url = 'https://test.api.amadeus.com/v1/security/oauth2/token';
  const res = await fetch(url, { method:'POST', headers: { 'content-type':'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type:'client_credentials', client_id: process.env.AMADEUS_CLIENT_ID, client_secret: process.env.AMADEUS_CLIENT_SECRET }) });
  if (!res.ok) throw new Error('Amadeus token error');
  return res.json();
}

export async function searchFlightAmadeus({ from, to, date, adults=1, currency='USD' }){
  const { access_token } = await amadeusToken();
  const url = new URL('https://test.api.amadeus.com/v2/shopping/flight-offers');
  url.searchParams.set('originLocationCode', from);
  url.searchParams.set('destinationLocationCode', to);
  url.searchParams.set('departureDate', date);
  url.searchParams.set('adults', String(adults));
  url.searchParams.set('currencyCode', currency);
  url.searchParams.set('max', '3');
  const res = await fetch(url.toString(), { headers: { Authorization: `Bearer ${access_token}` } });
  if (!res.ok) throw new Error('Amadeus search error');
  const data = await res.json();
  const best = data?.data?.[0] ? ({ price: data.data[0].price?.total, raw: data.data[0] }) : null;
  return { provider: 'amadeus', best };
}
