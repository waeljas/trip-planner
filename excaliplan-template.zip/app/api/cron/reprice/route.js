import { searchFlightKiwi, searchFlightAmadeus } from "../../providers/flights";

export async function GET(){
  // Fetch watchlist
  const res = await fetch(`${process.env.SELF_BASE_URL || ''}/api/price-watch`, { cache: 'no-store' });
  const watchlist = await res.json();

  const results = [];
  for (const w of watchlist){
    if (w.type === 'flight'){
      // Try Kiwi first (easy key). Fallback to Amadeus if configured.
      let r = null;
      if (process.env.TEQUILA_API_KEY){
        r = await searchFlightKiwi(w.params).catch(()=>null);
      }
      if (!r && process.env.AMADEUS_CLIENT_ID && process.env.AMADEUS_CLIENT_SECRET){
        r = await searchFlightAmadeus(w.params).catch(()=>null);
      }
      if (r) results.push({ id: w.id, type: 'flight', best: r.best });
    }
  }
  return new Response(JSON.stringify({ ok:true, results }), { headers: {'content-type':'application/json'} });
}
