// Minimal watchlist endpoint. In production use a DB or Vercel KV.
// POST { id?, type, params } -> upsert
// GET -> list
// DELETE?id=...
let mem = []; // ephemeral fallback

async function listKV(){
  if (!process.env.VERCEL_KV_REST_API_URL || !process.env.VERCEL_KV_REST_API_TOKEN) return null;
  try {
    const res = await fetch(`${process.env.VERCEL_KV_REST_API_URL}/get/excaliplan:watchlist`, {
      headers: { Authorization: `Bearer ${process.env.VERCEL_KV_REST_API_TOKEN}` }
    });
    if(!res.ok) return null;
    const data = await res.json();
    return data || null;
  } catch { return null; }
}
async function saveKV(val){
  if (!process.env.VERCEL_KV_REST_API_URL || !process.env.VERCEL_KV_REST_API_TOKEN) return false;
  try {
    const res = await fetch(`${process.env.VERCEL_KV_REST_API_URL}/set/excaliplan:watchlist`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.VERCEL_KV_REST_API_TOKEN}`, 'content-type':'application/json' },
      body: JSON.stringify(val)
    });
    return res.ok;
  } catch { return false; }
}

export async function GET(){
  const kv = await listKV();
  const list = kv ?? mem;
  return new Response(JSON.stringify(list), { headers: {'content-type':'application/json'} });
}

export async function POST(req){
  const body = await req.json();
  const item = { id: body.id || crypto.randomUUID(), type: body.type, params: body.params, createdAt: Date.now() };
  const kv = await listKV();
  const list = kv ?? mem;
  const idx = list.findIndex(x => x.id === item.id);
  if (idx>-1) list[idx] = item; else list.push(item);
  if (kv) await saveKV(list);
  return new Response(JSON.stringify(item), { headers: {'content-type':'application/json'} });
}

export async function DELETE(req){
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  const kv = await listKV();
  const list = kv ?? mem;
  const next = list.filter(x => x.id !== id);
  if (kv) await saveKV(next); else mem = next;
  return new Response(JSON.stringify({ ok:true }), { headers: {'content-type':'application/json'} });
}
