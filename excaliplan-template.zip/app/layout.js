export const metadata = {
  title: "Excaliplan — Trip Planner",
  description: "Free-form trip planning canvas + lists + budget + price watch."
};
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{margin:0, fontFamily:'system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial'}}>
        {children}
      </body>
    </html>
  );
}
