'use client';
import { useEffect, useMemo, useState } from 'react';
import { load, save } from './storage';

const defaultLists = [
  { id:'to-pack', name:'Things to Pack', items:[] },
  { id:'to-buy', name:'Things to Buy', items:[] },
  { id:'todo', name:'To-Do', items:[] }
];

export default function Lists({ baseCurrency, rates }){
  const [lists, setLists] = useState(load('lists', defaultLists));
  const [newListName, setNewListName] = useState('');

  useEffect(()=>save('lists', lists), [lists]);

  function addList(){
    if(!newListName.trim()) return;
    setLists([...lists, { id: crypto.randomUUID(), name: newListName.trim(), items: [] }]);
    setNewListName('');
  }
  function addItem(listId){
    setLists(lists.map(l => l.id===listId ? ({...l, items: [...l.items, { id: crypto.randomUUID(), title:'', qty:1, price:0, currency: baseCurrency, checked:false } ]}) : l));
  }
  function updateItem(listId, itemId, patch){
    setLists(lists.map(l => l.id===listId ? ({...l, items: l.items.map(it => it.id===itemId ? {...it, ...patch} : it)}) : l));
  }
  function removeItem(listId, itemId){
    setLists(lists.map(l => l.id===listId ? ({...l, items: l.items.filter(it => it.id!==itemId)}) : l));
  }
  function renameList(listId, name){
    setLists(lists.map(l => l.id===listId ? ({...l, name}) : l));
  }
  function deleteList(listId){
    setLists(lists.filter(l => l.id!==listId));
  }

  const totals = useMemo(()=>{
    const rate = (c)=> (rates?.[c] ?? 1);
    let total = 0;
    const perList = {};
    for (const l of lists){
      let t = 0;
      for (const it of l.items){
        const v = (Number(it.price)||0) * (Number(it.qty)||1) * (rate(baseCurrency)/rate(it.currency||baseCurrency));
        t += v;
      }
      perList[l.id] = t;
      total += t;
    }
    return { total, perList };
  }, [lists, baseCurrency, rates]);

  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 340px', height:'100%'}}>
      <section style={{padding:16, overflow:'auto'}}>
        <div style={{display:'flex', gap:8, marginBottom:12}}>
          <input placeholder="New list name" value={newListName} onChange={e=>setNewListName(e.target.value)} />
          <button onClick={addList}>Add List</button>
        </div>
        <div style={{display:'grid', gap:16}}>
          {lists.map(l => (
            <div key={l.id} style={{border:'1px solid #ddd', borderRadius:12, padding:12}}>
              <div style={{display:'flex', alignItems:'center', gap:8}}>
                <input value={l.name} onChange={e=>renameList(l.id, e.target.value)} style={{fontWeight:600, fontSize:16, flex:1}}/>
                <button onClick={()=>addItem(l.id)}>+ Item</button>
                <button onClick={()=>deleteList(l.id)} title="Delete list">🗑️</button>
              </div>
              <div style={{marginTop:8, display:'grid', gap:8}}>
                {l.items.map(it => (
                  <div key={it.id} style={{display:'grid', gridTemplateColumns:'24px 1fr 80px 90px 90px 28px', gap:8, alignItems:'center'}}>
                    <input type="checkbox" checked={it.checked} onChange={e=>updateItem(l.id, it.id, { checked: e.target.checked })} />
                    <input placeholder="Item" value={it.title} onChange={e=>updateItem(l.id, it.id, { title: e.target.value })} />
                    <input type="number" min="1" placeholder="Qty" value={it.qty} onChange={e=>updateItem(l.id, it.id, { qty: e.target.valueAsNumber||0 })} />
                    <input type="number" step="0.01" placeholder="Price" value={it.price} onChange={e=>updateItem(l.id, it.id, { price: e.target.valueAsNumber||0 })} />
                    <select value={it.currency} onChange={e=>updateItem(l.id, it.id, { currency: e.target.value })}>
                      {Object.keys(rates||{}).slice(0,50).concat(['USD','EUR','GBP','SAR','AED','KWD']).filter((v,i,a)=>a.indexOf(v)===i).map(c=> <option key={c} value={c}>{c}</option>)}
                    </select>
                    <button onClick={()=>removeItem(l.id, it.id)} title="Remove">✖</button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
      <aside style={{borderLeft:'1px solid #eee', padding:16}}>
        <h3 style={{marginTop:0}}>Totals</h3>
        <p><strong>{baseCurrency} {formatMoney(totals.total)}</strong></p>
        <ul>
          {lists.map(l => <li key={l.id}>{l.name}: {baseCurrency} {formatMoney(totals.perList[l.id]||0)}</li>)}
        </ul>
        <p style={{fontSize:12, color:'#666'}}>Rates auto-refresh when you change the base currency.</p>
      </aside>
    </div>
  );
}

function formatMoney(v){
  return (v||0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
