'use client';
import { useEffect, useMemo, useState } from 'react';
import { load, save } from './storage';

export default function Budget({ baseCurrency, rates }){
  const [budget, setBudget] = useState(load('budget', {
    total: 5000,
    categories: [
      { id:'flights', name:'Flights', limit: 2000 },
      { id:'accommodation', name:'Accommodation', limit: 1500 },
      { id:'food', name:'Food', limit: 800 },
      { id:'transport', name:'Transport', limit: 300 },
      { id:'activities', name:'Activities', limit: 400 }
    ],
    expenses: []
  }));
  useEffect(()=>save('budget', budget), [budget]);

  function addCategory(){
    setBudget({ ...budget, categories: [...budget.categories, { id: crypto.randomUUID(), name:'New Category', limit:0 }] });
  }
  function updateCategory(id, patch){
    setBudget({ ...budget, categories: budget.categories.map(c => c.id===id ? {...c, ...patch} : c) });
  }
  function removeCategory(id){
    setBudget({ ...budget, categories: budget.categories.filter(c => c.id!==id) });
  }
  function addExpense(){
    setBudget({ ...budget, expenses: [...budget.expenses, { id: crypto.randomUUID(), title:'', category:'', amount:0, currency:baseCurrency }] });
  }
  function updateExpense(id, patch){
    setBudget({ ...budget, expenses: budget.expenses.map(e => e.id===id ? {...e, ...patch} : e) });
  }
  function removeExpense(id){
    setBudget({ ...budget, expenses: budget.expenses.filter(e => e.id!==id) });
  }

  const fx = (from)=> (rates?.[from] ? (rates[baseCurrency]||1) / rates[from] : 1);

  const sums = useMemo(()=>{
    const byCat = {};
    let total = 0;
    for (const e of budget.expenses){
      const v = (Number(e.amount)||0) * fx(e.currency||baseCurrency);
      byCat[e.category||''] = (byCat[e.category||'']||0) + v;
      total += v;
    }
    return { total, byCat };
  }, [budget.expenses, rates, baseCurrency]);

  const remaining = Math.max(0, Number(budget.total||0) - sums.total);

  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, padding:16, height:'100%', overflow:'auto'}}>
      <section>
        <h3 style={{marginTop:0}}>Budget</h3>
        <label>Total ({baseCurrency})</label>
        <input type="number" value={budget.total} onChange={e=>setBudget({...budget, total: e.target.valueAsNumber||0})} />
        <h4>Categories</h4>
        <div style={{display:'grid', gap:8}}>
          {budget.categories.map(c => (
            <div key={c.id} style={{display:'grid', gridTemplateColumns:'1fr 1fr auto', gap:8, alignItems:'center'}}>
              <input value={c.name} onChange={e=>updateCategory(c.id,{name:e.target.value})} />
              <input type="number" value={c.limit} onChange={e=>updateCategory(c.id,{limit:e.target.valueAsNumber||0})} />
              <button onClick={()=>removeCategory(c.id)}>✖</button>
            </div>
          ))}
        </div>
        <button onClick={addCategory} style={{marginTop:8}}>+ Category</button>
      </section>
      <section>
        <h3 style={{marginTop:0}}>Expenses</h3>
        <button onClick={addExpense}>+ Expense</button>
        <div style={{display:'grid', gap:8, marginTop:8}}>
          {budget.expenses.map(e => (
            <div key={e.id} style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr auto', gap:8, alignItems:'center'}}>
              <input placeholder="Title" value={e.title} onChange={ev=>updateExpense(e.id,{title:ev.target.value})} />
              <select value={e.category} onChange={ev=>updateExpense(e.id,{category:ev.target.value})}>
                <option value="">(uncategorized)</option>
                {budget.categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <input type="number" placeholder="Amount" value={e.amount} onChange={ev=>updateExpense(e.id,{amount:ev.target.valueAsNumber||0})} />
              <select value={e.currency} onChange={ev=>updateExpense(e.id,{currency:ev.target.value})}>
                {Object.keys(rates||{}).slice(0,50).concat(['USD','EUR','GBP','SAR','AED','KWD']).filter((v,i,a)=>a.indexOf(v)===i).map(c=> <option key={c} value={c}>{c}</option>)}
              </select>
              <button onClick={()=>removeExpense(e.id)}>✖</button>
            </div>
          ))}
        </div>
        <div style={{marginTop:16, padding:12, border:'1px solid #eee', borderRadius:8}}>
          <strong>Total spent:</strong> {baseCurrency} {fmt(sums.total)}<br/>
          <strong>Remaining:</strong> {baseCurrency} {fmt(remaining)}
          <details style={{marginTop:8}}>
            <summary>By category</summary>
            <ul>
              {budget.categories.map(c => (
                <li key={c.id}>
                  {c.name}: {baseCurrency} {fmt(sums.byCat[c.id]||0)} / {fmt(c.limit||0)}
                </li>
              ))}
            </ul>
          </details>
        </div>
      </section>
    </div>
  );
}

function fmt(v){ return (v||0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
