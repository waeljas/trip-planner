'use client';
import { useEffect, useState } from 'react';

export default function Watch(){
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ type:'flight', from:'RUH', to:'DXB', date:'2025-12-20', adults:1, currency:'SAR' });

  async function refresh(){
    const r = await fetch('/api/price-watch', { cache:'no-store' });
    setList(await r.json());
  }
  useEffect(()=>{ refresh(); }, []);

  async function add(){
    const r = await fetch('/api/price-watch', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ type:'flight', params: form }) });
    await refresh();
  }
  async function del(id){
    await fetch(`/api/price-watch?id=${encodeURIComponent(id)}`, { method:'DELETE' });
    await refresh();
  }

  return (
    <div style={{padding:16}}>
      <h2>Price Watch</h2>
      <div style={{display:'grid', gridTemplateColumns:'repeat(6, 1fr) auto', gap:8, alignItems:'end'}}>
        <div><label>From</label><input value={form.from} onChange={e=>setForm({...form, from:e.target.value.toUpperCase()})}/></div>
        <div><label>To</label><input value={form.to} onChange={e=>setForm({...form, to:e.target.value.toUpperCase()})}/></div>
        <div><label>Date</label><input type="date" value={form.date} onChange={e=>setForm({...form, date:e.target.value})}/></div>
        <div><label>Adults</label><input type="number" min="1" value={form.adults} onChange={e=>setForm({...form, adults:e.target.valueAsNumber||1})}/></div>
        <div><label>Currency</label><input value={form.currency} onChange={e=>setForm({...form, currency:e.target.value.toUpperCase()})}/></div>
        <button onClick={add}>Add to Watch</button>
      </div>

      <h3 style={{marginTop:24}}>Your Watches</h3>
      <ul>
        {list.map(w => (
          <li key={w.id} style={{marginBottom:8}}>
            <code>{JSON.stringify(w.params)}</code>
            <button onClick={()=>del(w.id)} style={{marginLeft:8}}>Delete</button>
          </li>
        ))}
      </ul>

      <p style={{marginTop:24, color:'#555'}}>Every 6 hours, Vercel Cron calls <code>/api/cron/reprice</code> to fetch fresh prices (configure API keys in <code>.env</code>).</p>
    </div>
  );
}
