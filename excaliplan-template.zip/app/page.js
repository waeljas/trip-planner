'use client';

import dynamic from 'next/dynamic';
import { useEffect, useMemo, useState } from 'react';
import Lists from './ui/Lists';
import Budget from './ui/Budget';
import { load, save } from './ui/storage';

const Excalidraw = dynamic(
  async () => (await import('@excalidraw/excalidraw')).Excalidraw,
  { ssr: false }
);

export default function Page() {
  const [baseCurrency, setBaseCurrency] = useState(load('baseCurrency', 'USD'));
  const [rates, setRates] = useState({ USD: 1 });
  const [tab, setTab] = useState(load('tab', 'plan'));

  useEffect(() => { save('baseCurrency', baseCurrency); }, [baseCurrency]);
  useEffect(() => { save('tab', tab); }, [tab]);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/rates?base=${encodeURIComponent(baseCurrency)}`);
        const data = await res.json();
        setRates(data.rates || { [baseCurrency]: 1 });
      } catch (e) {
        console.error(e);
      }
    })();
  }, [baseCurrency]);

  return (
    <div style={{display:'grid', gridTemplateRows:'56px 1fr', height:'100vh'}}>
      <header style={{display:'flex', alignItems:'center', gap:12, padding:'0 16px', borderBottom:'1px solid #eee'}}>
        <strong>🗺️ Excaliplan</strong>
        <nav style={{display:'flex', gap:8, marginLeft:16}}>
          {['plan','lists','budget'].map(t => (
            <button key={t} onClick={()=>setTab(t)} style={btnStyle(tab===t)}>{t[0].toUpperCase()+t.slice(1)}</button>
          ))}
        </nav>
        <div style={{marginLeft:'auto', display:'flex', alignItems:'center', gap:8}}>
          <label>Base currency:</label>
          <select value={baseCurrency} onChange={e=>setBaseCurrency(e.target.value)}>
            {['USD','EUR','GBP','SAR','AED','KWD','QAR','OMR','BHD','JPY','CNY'].map(c=> <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </header>
      <main style={{height:'100%', overflow:'hidden'}}>
        {tab==='plan' && (
          <div style={{height:'100%'}}>
            <Excalidraw initialData={load('excalidraw', null)} onChange={(elements, appState, files)=>{
              // Persist minimal snapshot
              save('excalidraw', { elements, appState });
            }}/>
          </div>
        )}
        {tab==='lists' && <Lists baseCurrency={baseCurrency} rates={rates} />}
        {tab==='budget' && <Budget baseCurrency={baseCurrency} rates={rates} />}
      </main>
    </div>
  );
}

function btnStyle(active){
  return {
    padding:'8px 12px',
    borderRadius:8,
    border:'1px solid ' + (active ? '#222' : '#ddd'),
    background: active ? '#111' : '#fff',
    color: active ? '#fff' : '#000',
    cursor:'pointer'
  };
}
